package com.example.smartwallet;

public class Payment {
    public String timestamp;
    private static double cost;
    private static String name;
    private static String type;

    public Payment() {
        // Default constructor required for calls to DataSnapshot.getValue(User.class)
    }

    public static String getName() {
        return name;
    }

    public static double getCost() {
        return cost;
    }

    public static String getType() { return type; }
}
